@echo off
cd /d "%~dp0"
java --enable-native-access=ALL-UNNAMED -jar "J3 Asset Manager.jar"

